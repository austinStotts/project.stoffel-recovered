$('document').ready(function() {
  const signUpButton = $('#signUp');
  signUpButton.click(function() {
    chrome.storage.sync.set(
      {
        fbEmail: $('input[name="fbEmail"]').val(),
      },
      function() {
        chrome.runtime.sendMessage({
          type: 'signUp',
          data: {
            firstName: $('input[name="firstName"]').val(),
            lastName: $('input[name="lastName"]').val(),
            phone: $('input[name="phone"]').val(),
            fbEmail: $('input[name="fbEmail"]').val(),
            multiloginID: $('input[name="multiloginID"]').val(),
          },
        });
      }
    );
  });
});
